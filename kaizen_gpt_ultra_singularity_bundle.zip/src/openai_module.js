
// === OpenAI Cognition Engine ===
// Interactive module that lets you enter prompts and fetch completions

const openaiEndpoint = "https://api.openai.com/v1/chat/completions";

function createOpenAIPanel() {
  const panel = document.createElement("section");
  panel.className = "fixed top-4 left-4 bg-slate-900 text-white rounded-lg shadow-xl p-4 z-50 max-w-md space-y-2";
  panel.innerHTML = \`
    <h2 class="text-lg font-bold text-emerald-400">🧠 OpenAI Assistant</h2>
    <textarea id="userPrompt" rows="4" class="w-full rounded p-2 bg-slate-800 text-white" placeholder="Ask anything..."></textarea>
    <button id="sendPrompt" class="mt-2 bg-emerald-600 px-4 py-1 rounded">Send</button>
    <pre id="openaiResponse" class="text-sm whitespace-pre-wrap text-emerald-200 mt-3 max-h-64 overflow-auto"></pre>
  \`;

  document.body.appendChild(panel);

  document.getElementById("sendPrompt").onclick = async () => {
    const prompt = document.getElementById("userPrompt").value;
    const keyData = JSON.parse(localStorage.getItem("kaizen_api_keys") || "{}");
    const apiKey = keyData?.openai;

    if (!apiKey) {
      alert("Missing OpenAI API key in Settings Panel.");
      return;
    }

    const body = {
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7
    };

    try {
      const res = await fetch(openaiEndpoint, {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + apiKey,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      });

      if (!res.ok) throw new Error("OpenAI error");

      const data = await res.json();
      const msg = data.choices[0]?.message?.content;
      document.getElementById("openaiResponse").textContent = msg;
    } catch (e) {
      console.error("OpenAI call failed", e);
      document.getElementById("openaiResponse").textContent = "⚠️ OpenAI request failed.";
    }
  };
}

// Auto-run panel on load
window.addEventListener('DOMContentLoaded', createOpenAIPanel);
