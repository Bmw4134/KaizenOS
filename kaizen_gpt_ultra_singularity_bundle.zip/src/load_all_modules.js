
// === Auto Module Loader ===
// Dynamically invokes available modules on DOM load

window.addEventListener('DOMContentLoaded', () => {
  if (typeof fetchWeather === 'function') fetchWeather();
  if (typeof fetchCryptoPrices === 'function') fetchCryptoPrices();
  if (typeof loadCountries === 'function') loadCountries();
});
