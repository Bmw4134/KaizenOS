
// Macro Trainer UI
function createMacroPanel() {
  const el = document.createElement("div");
  el.className = "fixed top-4 right-4 bg-gray-900 text-white p-4 rounded-lg shadow-lg w-96";
  el.innerHTML = \`
    <h3 class="text-lg font-bold text-yellow-300 mb-2">🔁 Macro Trainer</h3>
    <button onclick="recordMacro()" class="bg-yellow-500 px-3 py-1 rounded mr-2">Record</button>
    <button onclick="playMacro()" class="bg-green-500 px-3 py-1 rounded">Play</button>
    <pre id="macroLog" class="mt-3 max-h-40 overflow-y-auto text-sm bg-black p-2 rounded"></pre>
  \`;
  document.body.appendChild(el);
}

window.addEventListener("DOMContentLoaded", createMacroPanel);
