
// === Country Intelligence Module ===
// Uses REST Countries API

const countriesAPI = "https://restcountries.com/v3.1/all";

async function loadCountries() {
  try {
    const res = await fetch(countriesAPI);
    if (!res.ok) throw new Error("Country API failed");
    const countries = await res.json();
    renderCountries(countries.slice(0, 5)); // Show only a few
  } catch (e) {
    console.error("Country load error:", e);
  }
}

function renderCountries(countries) {
  const el = document.createElement("div");
  el.className = "grid grid-cols-2 gap-4 p-4";
  countries.forEach(c => {
    const flag = c.flags?.svg || '';
    const block = document.createElement("div");
    block.innerHTML = `
      <div class="bg-gray-900 text-white p-3 rounded">
        <img src="${flag}" alt="${c.name.common}" class="w-10 mb-2">
        <div><strong>${c.name.common}</strong></div>
        <div>Region: ${c.region}</div>
        <div>Population: ${c.population.toLocaleString()}</div>
      </div>`;
    el.appendChild(block);
  });
  document.body.appendChild(el);
}
