
// === Crypto Module ===
// Uses CoinGecko API

const cryptoAPI = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd";

async function fetchCryptoPrices() {
  try {
    const res = await fetch(cryptoAPI);
    if (!res.ok) throw new Error("Crypto API error");
    const prices = await res.json();
    renderCrypto(prices);
  } catch (e) {
    console.error("Crypto fetch error:", e);
  }
}

function renderCrypto(prices) {
  const el = document.createElement("div");
  el.innerHTML = `
    <div class="p-4 bg-gray-800 text-green-400 rounded">
      <strong>Crypto Prices</strong><br>
      BTC: $${prices.bitcoin.usd}<br>
      ETH: $${prices.ethereum.usd}
    </div>`;
  document.body.appendChild(el);
}
