
// === Vibe Core Execution Engine ===

const vibeMemory = [];

function parseVibeCommand(text) {
  const lower = text.toLowerCase();
  if (lower.includes("add") && lower.includes("chart")) {
    return { action: "add", target: "chart", context: "prompt history" };
  }
  if (lower.includes("highlight") && lower.includes("fatigue")) {
    return { action: "highlight", target: "fatigue panel" };
  }
  return { action: "unknown", raw: text };
}

function generateComponentId(intent) {
  return `vibe-${intent.action}-${intent.target}-${Date.now()}`;
}

function buildUndo(intent) {
  return `remove ${intent.target}`;
}

function logToVibeMemory(intent) {
  vibeMemory.push({
    timestamp: new Date().toISOString(),
    command: intent,
    componentId: generateComponentId(intent),
    undoAction: buildUndo(intent)
  });
  updateVibeConsole();
}

function isDuplicate(newIntent) {
  return vibeMemory.some(entry =>
    entry.command.action === newIntent.action &&
    entry.command.target === newIntent.target &&
    entry.command.context === newIntent.context
  );
}

function executeIntent(intent) {
  if (intent.action === "add" && intent.target === "chart") {
    const container = document.getElementById("promptPanel") || document.body;
    const chart = document.createElement("div");
    chart.className = "p-4 m-4 bg-white rounded shadow";
    chart.innerText = "📊 Chart injected by Vibe!";
    container.appendChild(chart);
  } else if (intent.action === "highlight" && intent.target === "fatigue panel") {
    const panel = document.getElementById("fatiguePanel");
    if (panel) {
      panel.classList.add("ring-4", "ring-yellow-400");
    }
  } else {
    console.log("Unknown or unhandled command:", intent);
  }
}

function updateVibeConsole() {
  const consolePanel = document.getElementById("vibeConsole");
  if (!consolePanel) return;
  consolePanel.innerHTML = "<strong>🧠 Vibe Memory:</strong><br>" + vibeMemory.map(entry =>
    `✓ ${entry.command.action} → ${entry.command.target} (${entry.timestamp})`
  ).join("<br>");
}

function handleVibeCommand(transcript) {
  const intent = parseVibeCommand(transcript);
  if (!isDuplicate(intent)) {
    executeIntent(intent);
    logToVibeMemory(intent);
  } else {
    alert("Vibe: You've already done that. Want to update or undo?");
  }
}
