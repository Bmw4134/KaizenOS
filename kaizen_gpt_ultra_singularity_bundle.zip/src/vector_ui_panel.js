
// Vector DB UI Viewer Panel
function showVectorDBPanel() {
  const panel = document.createElement('div');
  panel.className = 'fixed bottom-4 right-4 bg-slate-800 text-white p-4 rounded-lg shadow-lg z-50 w-96';
  panel.innerHTML = \`
    <h3 class="text-lg font-bold text-blue-300 mb-2">🧬 Vector DB Viewer</h3>
    <button class="bg-blue-600 px-3 py-1 rounded" onclick="listVectors()">Refresh</button>
    <ul id="vectorList" class="mt-2 max-h-60 overflow-y-scroll text-sm"></ul>
  \`;
  document.body.appendChild(panel);
}

function listVectors() {
  const list = document.getElementById("vectorList");
  list.innerHTML = "";
  const stored = JSON.parse(localStorage.getItem("hf_stored_texts") || "[]");
  stored.forEach((v, i) => {
    const li = document.createElement("li");
    li.textContent = v.text.slice(0, 100);
    list.appendChild(li);
  });
}

window.addEventListener("DOMContentLoaded", showVectorDBPanel);
