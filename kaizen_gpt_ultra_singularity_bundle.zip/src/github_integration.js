
// === GitHub Integration Engine ===
// Automatically scan user's GitHub repos (given token) and index relevant modules

async function fetchGitHubRepos(token) {
  const headers = { Authorization: `token ${token}` };
  const res = await fetch('https://api.github.com/user/repos', { headers });
  if (!res.ok) return console.error('GitHub fetch failed');
  const repos = await res.json();
  console.log('[GitHub] Repos:', repos.map(r => r.full_name));
  return repos;
}

async function scanAndInjectModules(token, keyword = "kaizen") {
  const repos = await fetchGitHubRepos(token);
  const matched = repos.filter(r => r.name.toLowerCase().includes(keyword));
  console.log('[Kaizen] Matched Modules:', matched);
  localStorage.setItem("kaizen_matched_modules", JSON.stringify(matched));
}
