# LLM Macro Orchestrator

Send prompt chains to OpenAI and return parsed JSON outputs.

Functions:
- `runLLMMacro(prompt)`
- Used to trigger chained logic in dashboard.
