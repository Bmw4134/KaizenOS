# GitHub File Walker

Walk a full repo and parse file paths with the GitHub API.

Example:
```js
walkRepo('https://github.com/user/repo')
```