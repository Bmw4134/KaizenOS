# Vector DB

This module enables local storage of embeddings using IndexedDB. It supports:
- Saving vectors
- Querying for cosine similarity
- Front-end UI viewer integration

Usage:
```js
saveVector(...)
querySimilar(...)
```