# Supabase Sync

Real-time sync to Supabase tables.

- Auth + CRUD included
- Can cache to localStorage
- Good for user sessions, persistent data
