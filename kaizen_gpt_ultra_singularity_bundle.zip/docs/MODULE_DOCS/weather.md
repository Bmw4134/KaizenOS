
# 🌤️ Weather Module (Open-Meteo)

## Description
This module fetches real-time weather data using the Open-Meteo API.

## Features
- No API key required
- Shows current temperature and wind speed
- Can be extended for hourly/daily forecasts

## Usage
Call:
```js
fetchWeather();
```

Requires:
```html
<script src="src/weather_module.js"></script>
```

Data Example:
```json
{
  "temperature": 21.4,
  "windspeed": 5.8
}
```
