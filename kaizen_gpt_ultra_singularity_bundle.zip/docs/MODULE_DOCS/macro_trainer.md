# Macro Trainer

This module records and replays user interaction macros.

Features:
- Event listeners
- Session replay
- Save/load macros
