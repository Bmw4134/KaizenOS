
# 🌍 Countries Module (REST Countries API)

## Description
This module fetches country data including name, region, population, and flag.

## Features
- Displays country cards with flags
- Lists basic stats
- Easy to expand to include capital, language, etc.

## Usage
Call:
```js
loadCountries();
```

Example Render:
```
🇺🇸 United States
Region: Americas
Population: 331,002,651
```
