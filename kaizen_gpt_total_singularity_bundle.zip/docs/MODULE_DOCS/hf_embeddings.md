
# Hugging Face Embeddings Module

## Purpose

Integrate the Hugging Face Inference API to extract semantic vector representations (embeddings) of user-entered text. Enables memory and similarity search features across the KaizenGPT dashboard.

## Key Functions

- **getEmbedding(text)**  
  Fetches a 384-dimensional vector from Hugging Face's MiniLM model.

- **storeTextWithEmbedding(text, embedding)**  
  Saves text and its embedding in `localStorage`.

- **findSimilarTexts(input)**  
  Computes cosine similarity between the input and all stored texts.

## Setup Instructions

1. Add your Hugging Face API key via the UI or browser console:  
   `localStorage.setItem('hf_api_key', 'your_hf_key_here');`

2. Use the provided UI panel to store text entries and perform similarity search.

3. All embeddings are stored client-side for privacy and speed.
