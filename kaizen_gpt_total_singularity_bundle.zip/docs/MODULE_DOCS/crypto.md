
# 💰 Crypto Module (CoinGecko)

## Description
This module fetches live cryptocurrency prices for Bitcoin and Ethereum.

## Features
- Pulls USD prices
- No authentication needed
- Ready for chart integration

## Usage
Call:
```js
fetchCryptoPrices();
```

Data format:
```json
{
  "bitcoin": { "usd": 29123 },
  "ethereum": { "usd": 1742 }
}
```
