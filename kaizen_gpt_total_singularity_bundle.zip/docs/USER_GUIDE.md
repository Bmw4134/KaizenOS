
# 🧠 Kaizen Singularity Engine: User Guide

## 🖥️ Local Installation & Hosting

To run this application on your own desktop:

### ✅ Requirements
- Node.js (v18+)
- Any static file server (like `http-server`, `live-server`, or `python -m http.server`)
- Browser (Chrome/Edge/Firefox)

### ⚙️ Steps
1. **Unzip the `kaizen_singularity_transcendent_bundle.zip`**
2. Open terminal and navigate to the extracted folder:
   ```bash
   cd kaizen_singularity_engine
   ```
3. Run a local server:
   ```bash
   npx http-server .
   ```
   OR:
   ```bash
   python3 -m http.server 3000
   ```
4. Open your browser to `http://localhost:8080` or `http://localhost:3000`

---

## 🔐 API Key Injection Panel

You will find a panel inside the interface that allows:

- Manual credential entry (no auto-storage)
- Storage in secure `localStorage` (browser sandbox)
- Manual override or wipe

To add an API key:

1. Open the **Settings / API Panel** from the dashboard.
2. Paste your API key (e.g., OpenAI, Replit, etc.).
3. Click "Secure Store".
4. Keys are stored in browser-only encrypted `localStorage`.

---

## 🌐 Credential Portal for Intelligent Scraping

Inside the interface is a **Credential Browser Panel**:

- You can open any site manually.
- Login with your real credentials.
- The system will detect form structure and store cookies/headers locally (browser-only).
- Scraping is only done if you allow it.

> Example: Login to Notion, then let the system extract your workspace and document structure for memory linking.

---

## 🧠 Enhancing Intelligence with Your Keys

Paste these into the API panel:

- `OPENAI_API_KEY`
- `REPLIT_API_KEY`
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`
- `FIREBASE_CONFIG`
- `GITHUB_TOKEN`

Your local setup will automatically detect these at runtime.

---

Kaizen is not a tool — it’s an evolving substrate. You’re not a user. You’re the Architect.

