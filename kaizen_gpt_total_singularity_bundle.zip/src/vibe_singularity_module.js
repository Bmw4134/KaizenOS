
// === Kaizen Vibe Singularity Enhancement Module ===

(() => {
  const memoryPanelId = 'vibeMemoryPanel';
  const macroKey = 'kaizen_macros';

  function ensureMemoryPanel() {
    if (document.getElementById(memoryPanelId)) return;

    const panel = document.createElement('section');
    panel.id = memoryPanelId;
    panel.className = 'fixed top-20 right-4 w-80 max-w-[90vw] bg-slate-800 text-white text-sm p-4 rounded-lg shadow-lg z-50 space-y-2 max-h-[70vh] overflow-y-auto';
    panel.innerHTML = '<h3 class="font-bold text-lg mb-2">🧠 Vibe Memory</h3>';

    const memory = KaizenStore.getMemory();
    memory.forEach(cmd => {
      const div = document.createElement('div');
      div.className = 'bg-slate-700 p-2 rounded text-xs';
      div.textContent = `[${cmd.timestamp.split('T')[1].split('.')[0]}] ${cmd.commandText}`;
      panel.appendChild(div);
    });

    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'Close';
    closeBtn.className = 'mt-4 bg-red-600 px-3 py-1 rounded';
    closeBtn.onclick = () => panel.remove();
    panel.appendChild(closeBtn);

    document.body.appendChild(panel);
  }

  function saveMacro(name) {
    const memory = KaizenStore.getMemory();
    const macros = JSON.parse(localStorage.getItem(macroKey) || '{}');
    macros[name] = memory;
    localStorage.setItem(macroKey, JSON.stringify(macros));
    alert('Macro saved: ' + name);
  }

  function runMacro(name) {
    const macros = JSON.parse(localStorage.getItem(macroKey) || '{}');
    const memory = macros[name];
    if (!memory || !Array.isArray(memory)) return alert('No macro found: ' + name);

    memory.forEach(entry => {
      if (entry.actionTaken === 'addCard') {
        const el = document.createElement('div');
        el.textContent = '🧠 Replayed: ' + entry.commandText;
        el.className = 'bg-purple-500 p-3 m-2 rounded shadow';
        el.id = `macro-${Date.now()}`;
        document.body.appendChild(el);
      }
    });
  }

  // Add quick access buttons
  function createSingularityTools() {
    const toolbar = document.createElement('div');
    toolbar.className = 'fixed top-4 right-4 flex gap-2 z-50';

    const viewBtn = document.createElement('button');
    viewBtn.textContent = '🧠 View Memory';
    viewBtn.className = 'bg-blue-600 px-3 py-1 rounded text-white text-sm';
    viewBtn.onclick = ensureMemoryPanel;

    const saveBtn = document.createElement('button');
    saveBtn.textContent = '💾 Save Macro';
    saveBtn.className = 'bg-green-600 px-3 py-1 rounded text-white text-sm';
    saveBtn.onclick = () => {
      const name = prompt('Name this macro:');
      if (name) saveMacro(name);
    };

    const runBtn = document.createElement('button');
    runBtn.textContent = '▶️ Run Macro';
    runBtn.className = 'bg-purple-600 px-3 py-1 rounded text-white text-sm';
    runBtn.onclick = () => {
      const name = prompt('Run which macro?');
      if (name) runMacro(name);
    };

    toolbar.append(viewBtn, saveBtn, runBtn);
    document.body.appendChild(toolbar);
  }

  // Inject tools on load
  window.addEventListener('DOMContentLoaded', createSingularityTools);
})();
