
// === KaizenStore Module ===

const KaizenStore = (() => {
  // LocalStorage key
  const STORAGE_KEY = 'kaizen_vibe_memory';

  // In-memory store
  let vibeMemory = [];

  // Load from localStorage if available
  function load() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        vibeMemory = JSON.parse(stored);
      } catch (e) {
        console.error('Failed to parse stored Kaizen data:', e);
        vibeMemory = [];
      }
    }
  }

  // Save to localStorage
  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(vibeMemory));
  }

  // Add a command to memory
  function logCommand(commandText, intent, targetElementId, actionTaken) {
    const entry = {
      timestamp: new Date().toISOString(),
      commandText,
      intent,
      targetElementId,
      actionTaken
    };
    vibeMemory.push(entry);
    save();
  }

  // Get the full vibe memory
  function getMemory() {
    return vibeMemory;
  }

  // Undo last command (if possible)
  function undoLast() {
    const last = vibeMemory.pop();
    if (!last) return null;
    save();
    return last;
  }

  // Clear all
  function reset() {
    vibeMemory = [];
    localStorage.removeItem(STORAGE_KEY);
  }

  load(); // Initialize on load

  return {
    logCommand,
    getMemory,
    undoLast,
    reset
  };
})();
