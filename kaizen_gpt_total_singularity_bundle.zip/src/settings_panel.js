
// === Settings Panel for API Keys and Credentials ===

window.addEventListener('DOMContentLoaded', () => {
  const panel = document.createElement('section');
  panel.className = 'fixed bottom-4 right-4 bg-slate-900 text-white rounded-lg shadow-xl p-4 z-50 max-w-xs space-y-2';
  panel.innerHTML = `
    <h2 class="text-lg font-bold text-cyan-400">🔐 API Keys</h2>
    <label class="block text-sm">OpenAI Key
      <input type="text" id="openaiKey" class="w-full mt-1 rounded px-2 py-1 bg-slate-800 text-white border border-cyan-400">
    </label>
    <label class="block text-sm">Supabase URL
      <input type="text" id="supabaseUrl" class="w-full mt-1 rounded px-2 py-1 bg-slate-800 text-white border border-cyan-400">
    </label>
    <label class="block text-sm">Supabase Key
      <input type="text" id="supabaseKey" class="w-full mt-1 rounded px-2 py-1 bg-slate-800 text-white border border-cyan-400">
    </label>
    <button class="mt-3 bg-cyan-600 px-3 py-1 rounded text-white text-sm" id="saveKeysBtn">🔒 Save Keys</button>
    <div id="saveStatus" class="text-xs text-green-400 pt-1"></div>
  `;

  document.body.appendChild(panel);

  document.getElementById('saveKeysBtn').onclick = () => {
    const keys = {
      openai: document.getElementById('openaiKey').value,
      supabaseUrl: document.getElementById('supabaseUrl').value,
      supabaseKey: document.getElementById('supabaseKey').value
    };
    localStorage.setItem('kaizen_api_keys', JSON.stringify(keys));
    document.getElementById('saveStatus').textContent = '✅ Keys saved locally';
  };
});
