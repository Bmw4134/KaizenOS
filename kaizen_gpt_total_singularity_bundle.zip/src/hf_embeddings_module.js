
// hf_embeddings_module.js
// Hugging Face Inference API integration for text embeddings

const HF_API_URL = 'https://api-inference.huggingface.co/pipeline/feature-extraction/sentence-transformers/all-MiniLM-L6-v2';
const HF_API_KEY = localStorage.getItem('hf_api_key');

async function getEmbedding(text) {
    const response = await fetch(HF_API_URL, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${HF_API_KEY}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ inputs: text })
    });

    if (!response.ok) throw new Error('Hugging Face API error');
    const data = await response.json();
    return data[0]; // Return embedding vector
}

const storedTexts = JSON.parse(localStorage.getItem('hf_stored_texts') || '[]');

function storeTextWithEmbedding(text, embedding) {
    storedTexts.push({ text, embedding });
    localStorage.setItem('hf_stored_texts', JSON.stringify(storedTexts));
}

function cosineSimilarity(vecA, vecB) {
    const dot = vecA.reduce((sum, val, i) => sum + val * vecB[i], 0);
    const normA = Math.sqrt(vecA.reduce((sum, val) => sum + val * val, 0));
    const normB = Math.sqrt(vecB.reduce((sum, val) => sum + val * val, 0));
    return dot / (normA * normB);
}

async function findSimilarTexts(input) {
    const inputEmbedding = await getEmbedding(input);
    return storedTexts
        .map(entry => ({ text: entry.text, score: cosineSimilarity(inputEmbedding, entry.embedding) }))
        .sort((a, b) => b.score - a.score);
}

export { getEmbedding, storeTextWithEmbedding, findSimilarTexts };
