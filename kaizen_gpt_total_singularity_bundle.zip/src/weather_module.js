
// === Weather Module ===
// Uses Open-Meteo free API

const weatherAPI = "https://api.open-meteo.com/v1/forecast?latitude=40.7128&longitude=-74.0060&current_weather=true";

async function fetchWeather() {
  try {
    const res = await fetch(weatherAPI);
    if (!res.ok) throw new Error("Weather API request failed.");
    const data = await res.json();
    console.log("🌤️ Weather:", data);
    renderWeather(data.current_weather);
  } catch (e) {
    console.error("Weather fetch error:", e);
  }
}

function renderWeather(weather) {
  const el = document.createElement("div");
  el.innerHTML = `
    <div class="p-4 bg-blue-900 text-white rounded">
      <strong>Weather:</strong><br>
      Temperature: ${weather.temperature}°C<br>
      Wind: ${weather.windspeed} km/h
    </div>`;
  document.body.appendChild(el);
}
